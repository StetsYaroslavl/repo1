namespace task2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            int b = a.Length;
            if (b < 5)
            {
                MessageBox.Show("���� ����������");
            }
            else
            {
                MessageBox.Show("���� ��������");
            }
        }
    }
}
